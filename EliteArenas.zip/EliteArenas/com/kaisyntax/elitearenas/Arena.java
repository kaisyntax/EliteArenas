package com.kaisyntax.elitearenas;

import org.bukkit.plugin.java.JavaPlugin;

public class EliteArenas extends JavaPlugin {

    @Override
    public void onEnable() {
        getLogger().info("Elite Arenas plugin has been enabled!");

        this.getCommand("elitearenas").setExecutor(new ArenaCommand());
    }

    @Override
    public void onDisable() {
        getLogger().info("Elite Arenas plugin has been disabled!");
    }
}